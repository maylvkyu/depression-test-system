from django.shortcuts import render

# Create your views here.
def getTests(request):
    return render(request, 'getTested.html')