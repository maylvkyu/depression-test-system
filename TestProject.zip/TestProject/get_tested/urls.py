from django.urls import path
from get_tested import views

urlpatterns = [
    path('', views.getTests, name="getTested"),
]