from django.db import models

# Create your models here.

class Room(models.Model):
    #user #host =
    #topic =
    name = models.CharField(max_length=200)
    description = models.TextField(null=True, blank=True)
    #store users that are active in a room #participants =
    updated = models.DateTimeField(auto_now=True) #snapshot of any changes in a table/model
    created = models.DateTimeField(auto_now_add=True)

    def __str__(self): #self is used to refer to an instance of the class 
        return self.name
    #string representation of the room
        
