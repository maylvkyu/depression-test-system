from django.urls import path
from base import views

urlpatterns = [
    path('', views.home, name="home"),
    path('room/<str:pk>/', views.room, name="room"),
    path('get_tested/', views.getTests, name="tests"),
    path('cesdRtest/', views.cesdRtest, name="firstTest"),
    path('sent_analysis/', views.sentAnalysis, name="secondTest"),
    path('about', views.about, name="about"),
    path('treatments', views.treatments, name="treatments"),
    path('nearest_psych', views.nearestPsych, name="nearestpsych")
]