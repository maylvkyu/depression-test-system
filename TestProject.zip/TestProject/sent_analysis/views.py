from django.shortcuts import render

# Create your views here.

def sentAnalysis(request):
    return render(request, 'sent-based-test.html')
