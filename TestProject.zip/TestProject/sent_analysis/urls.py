from django.urls import path
from sent_analysis import views

urlpatterns = [
    path('', views.sentAnalysis, name="sentAnalysisPage"),
]