from django.shortcuts import render

# Create your views here.

def CesdRtest(request):
    return render(request, 'cesd-R-test.html')

