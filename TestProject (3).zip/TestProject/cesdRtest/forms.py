from django import forms
from django.forms import ModelForm
from .models import Question, Choice

#class CESDRForm(ModelForm):
#class Meta:
 #   model = Question, Choice
  #  fields = ['question']

#class CESDRform (forms.Form):
 #   question = forms.CharField(questions, widget=forms.RadioSelect(choices=answer_choices))