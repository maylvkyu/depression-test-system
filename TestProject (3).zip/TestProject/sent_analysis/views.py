from django.shortcuts import render
from django.http import HttpResponseRedirect
from .forms import SentForm
import io
import os

from transformers import AutoTokenizer, AutoModelForSequenceClassification 
from scipy.special import softmax

# Create your views here.

def sentAnalysis(request):
    result=0
    if request.method == 'POST':

        text = request.POST['sent_text']

        #text = input()
        text_words = []

        for word in text.split(' '):
            if word.startswith('@') and len(word) > 1:
                word = '@user'
            elif word.startswith('http'):
                word = "http"
            text_words.append(word)

    #print(tweet_words)
        processed_text = " ".join(text_words)

    #build model
        roberta = "cardiffnlp/twitter-roberta-base-sentiment"

        model = AutoModelForSequenceClassification.from_pretrained(roberta)
        tokenizer = AutoTokenizer.from_pretrained(roberta)

    #convert tweets into pytoarch tensors and then pass into model
    #sentiment analysis

        encoded_text = tokenizer(processed_text, return_tensors = 'pt')

        output = model(encoded_text['input_ids'], encoded_text['attention_mask'])

        # output of analysis -> SequenceClassifierOutput(loss=None, logits=tensor([[-1.2903,  0.3605,  1.0500]], grad_fn=<AddmmBackward0>), hidden_states=None, attentions=None)
        #the tensor is to be converted to probability to check the sentiment of the tweet
        #convert output of model into probability using softmax
        #detach() -> select list, numpy() -> compare it into a numpy array

        scores = output[0][0].detach().numpy()

        scores = softmax(scores)

        labels = ['Negative','Neutral','Positive']
       
        for i in range(len(scores)):
            l = labels[i]
            s = scores[i]
            print(l,s)

        if scores[2] == scores.max():
            print("Max value is positive. The sentiment is positive with a", round((scores[2]), 2), "score.")
            result = scores[2]
        elif scores[0] == scores.max():
            print("Max value is negative. The sentiment is negative with a", round((scores[0]), 2), "score.")
            result = scores[0]
        else:
            print("The sentiment is neutral with a", round((scores[1]), 2), "score.")
            result = scores[1]

    context = {"results":result}
    return render(request, 'base/sent-based-test.html', context)

