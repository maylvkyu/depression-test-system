from django import forms

class SentForm(forms.Form):
    sent_text = forms.CharField(label="Sent Text", max_length=300)

    