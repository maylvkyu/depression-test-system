from django.shortcuts import render
#from .forms import CESDRform
from .models import Question, Choice
# Create your views here.

def CesdRtest (request):
    question = Question.objects.all()
    choice = Choice.objects.all()
    context = {'questions':question, 'choices':choice}
    return render(request, 'base/cesd-R-test.html', context=context)



#def CesdRtest(request, pk):
    #form = Question.objects.get(id=pk)
    #if request.method == 'POST':
        #form = CESDRform(request.POST)
        #if form.is_valid():
       #     return render(request, 'cesd-R-test.html')
      #  else:
     #       form = CESDRform()
    #return render(request, 'cesd-R-test.html', {'form':form})
