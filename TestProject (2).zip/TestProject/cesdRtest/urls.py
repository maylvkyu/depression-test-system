from django.urls import path
from cesdRtest import views


urlpatterns = [
    path('', views.CesdRtest, name="firstTest"),
]

