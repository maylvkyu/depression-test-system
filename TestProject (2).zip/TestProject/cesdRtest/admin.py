from django.contrib import admin
from .models import Question, Choice, Submission
# Register your models here.

class QuestionInline(admin.TabularInline):
    model=Question

class ChoiceInLine(admin.TabularInline):
    model=Choice

class QuestionAdmin(admin.ModelAdmin):
    inlines = [ChoiceInLine]

class SubmissionAdmin(admin.ModelAdmin):
    list_display=('user_email', 'status')

admin.site.register(Question, QuestionAdmin)
admin.site.register(Choice)
admin.site.register(Submission, SubmissionAdmin)

