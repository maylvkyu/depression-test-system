from django.db import models

# Create your models here.



class Question(models.Model):
    text = models.CharField(max_length=200)
    pub_date = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return str(self.text)

class Choice(models.Model):
    answer_choices = [
        ('Rarely or None of the Time', '0'),
        ('Some or a Little of the Time', '1'),
        ('Occasionally or a Moderate Amount of Time', '2'),
        ('Most or All of the Time', '3'),
    ]
    question = models.ForeignKey(Question, on_delete=models.CASCADE, null=True)
    text = models.IntegerField(max_length=100, choices= answer_choices, default=0)

    def __str__(self):
        return f"{self.question.text}:{self.text}"

class Results(models.Model):
    question = models.ForeignKey(Question, on_delete=models.CASCADE, null=True)
    answer = models.ForeignKey(Choice, on_delete=models.CASCADE, null=True)

    #def calculateScore(question, answer):
     #   for question.id == 4 && 8 && 12 && 16 in question:
      #      if answer == 1:
       #         score += 3
        #    elif answer == 2:
         #       score += 2
          #  elif answer == 3:
           #     score += 1:
            #else:
             #   score += 0

        #return

class Submission(models.Model):
    question = models.ForeignKey(Question, on_delete=models.PROTECT, null=True)
    user_email = models.EmailField(max_length=250)
    answer = models.ManyToManyField(Choice)
    status = models.CharField(max_length=250)

#class Score(models.Models):


