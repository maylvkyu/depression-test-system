from django.apps import AppConfig


class SentAnalysisConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'sent_analysis'
