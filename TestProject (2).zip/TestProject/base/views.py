from django.shortcuts import render
from .models import Room
from cesdRtest.models import Question
# Create your views here.

#eg
#rooms = [
  #  {'id': 1, 'name':'Lets learn Python!'},
   # {'id': 2, 'name': 'Design with me'},
    #{'id': 3, 'name': 'Frontend developers'},
#]

#{'rooms':rooms} room->
#{'how we adress it in the template:specify what is being passed'}
#variables can be passed into curly braces
#def room(request, pk):
 #   room = None
  #  for i in rooms:
   #     if i['id'] == int(pk):
    #        room = i
    #context = {'room':room}
    #return render(request, 'base/room.html', context)

def room(request, pk):
    room = Room.objects.get(id=pk)
    context = {'room':room}
    return render(request, 'base/room.html', context)

def home(request):
    rooms = Room.objects.all()
    context = {'rooms':rooms}
    return render(request, 'base/home.html', context) #request -> object

def getTests(request):
    return render(request, 'base/getTested.html')

#def cesdRtest(request):
    form = Question.objects.all()
    context = {'questions':form}
    return render(request, 'base/cesd-R-test.html', context)
    #return render(request, 'cesd-R-test.html')

#def sentAnalysis(request):
    return render(request, 'base/sent-based-test.html')

def about(request):
    return render(request, 'base/about.html')

def treatments(request):
    return render(request, 'base/treatments.html')

def nearestPsych(request):
    return render(request, 'base/nearestpsych.html')
    
def events(request):
    return render(request, 'base/events.html')



