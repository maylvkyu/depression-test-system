from django.db import models
from django.contrib.auth.models import User
# Create your models here.

class Topic(models.Model):
    name = models.CharField(max_length=200)

    def __str__(self):
        return self.name

class Room(models.Model):
    #user 
    host = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    topic = models.ForeignKey(Topic, on_delete=models.SET_NULL, null=True)
    name = models.CharField(max_length=200)
    description = models.TextField(null=True, blank=True)
    #store users that are active in a room 
    #participants =
    updated = models.DateTimeField(auto_now=True) #snapshot of any changes in a table/model
    created = models.DateTimeField(auto_now_add=True)

    def __str__(self): #self is used to refer to an instance of the class 
        return self.name
    #string representation of the room

class Message(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    room = models.ForeignKey(Room, on_delete=models.CASCADE)
    body = models.TextField()
    updated = models.DateTimeField(auto_now=True)
    created = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.body[0:50]

#    class Events(models.Model):
 #       name = models.CharField(max_length=100)
  #      url = models.URLField()

#        def __str__(self):
 #           return self.name
